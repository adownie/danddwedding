OPTIONAL DEFAULT SETTINGS
----------------------------------

If you need to implement custom settings in your theme, you can place a file
named STARTER.settings.yml here, where "STARTER" is the name of your sub-theme.

See zurb-foundation/config/install/zurb_foundation.settings.yml for example.